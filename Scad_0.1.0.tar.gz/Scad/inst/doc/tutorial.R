## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----standard-lqa-------------------------------------------------------------
library(Scad)

# Generate example data
set.seed(123)
n <- 100
p <- 50
X <- matrix(rnorm(n * p), n, p)
beta_true <- c(3, 3, 2, 1.5, 1, rep(0, p - 5))
y <- X %*% beta_true + rnorm(n, sd = 0.5)

# Fit SCAD using standard LQA
fit_lqa <- lqa_scad(y, X, lambda = 0.5, a = 3.7)

# Check results
cat("Converged:", fit_lqa$converged, "\n")
cat("Iterations:", fit_lqa$iterations, "\n")
cat("Non-zero coefficients:", sum(fit_lqa$beta != 0), "\n")
cat("True non-zero:", sum(beta_true != 0), "\n")

## ----qr-version---------------------------------------------------------------
# Fit SCAD using QR decomposition
fit_qr <- lqa_scad_improved(y, X, lambda = 0.5, a = 3.7, decomposition = "qr")

cat("Converged:", fit_qr$converged, "\n")
cat("Iterations:", fit_qr$iterations, "\n")
cat("Non-zero coefficients:", sum(fit_qr$beta != 0), "\n")

## ----svd-version--------------------------------------------------------------
# Fit SCAD using SVD decomposition
fit_svd <- lqa_scad_improved(y, X, lambda = 0.5, a = 3.7, decomposition = "svd")

cat("Converged:", fit_svd$converged, "\n")
cat("Iterations:", fit_svd$iterations, "\n")
cat("Non-zero coefficients:", sum(fit_svd$beta != 0), "\n")

## ----comparison---------------------------------------------------------------
# Compare estimation accuracy
methods <- c("Standard LQA", "Improved (QR)", "Improved (SVD)")
beta_estimates <- list(
  fit_lqa$beta,
  fit_qr$beta,
  fit_svd$beta
)

# Compute L2 error
l2_errors <- sapply(beta_estimates, function(beta) {
  sqrt(sum((beta - beta_true)^2))
})

# Compute sparsity recovery
sparsity <- sapply(beta_estimates, function(beta) {
  sum(beta != 0)
})

# Create comparison table
comparison <- data.frame(
  Method = methods,
  L2_Error = round(l2_errors, 4),
  Non_Zero = sparsity,
  Iterations = c(
    fit_lqa$iterations,
    fit_qr$iterations,
    fit_svd$iterations
  )
)

print(comparison)

## ----high-dim-----------------------------------------------------------------
# High-dimensional setting
set.seed(456)
n <- 200
p <- 100
X <- matrix(rnorm(n * p), n, p)
# Add correlation structure
cor_mat <- 0.5^abs(outer(1:p, 1:p, "-"))
X <- X %*% chol(cor_mat)
beta_true <- c(3, 3, 2, 1.5, 1, rep(0, p - 5))
y <- X %*% beta_true + rnorm(n, sd = 1)

# Fit with improved method (SVD is robust for high dimensions)
fit_hd <- lqa_scad_improved(
  y, X, lambda = 0.8, a = 3.7,
  decomposition = "svd"
)

cat("High-dimensional results:\n")
cat("Converged:", fit_hd$converged, "\n")
cat("Iterations:", fit_hd$iterations, "\n")
cat("Non-zero coefficients:", sum(fit_hd$beta != 0), "\n")
cat("True non-zero:", sum(beta_true != 0), "\n")
cat("L2 error:", round(sqrt(sum((fit_hd$beta - beta_true)^2)), 4), "\n")

