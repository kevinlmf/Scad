library(testthat)
library(Scad)

test_check("Scad")
